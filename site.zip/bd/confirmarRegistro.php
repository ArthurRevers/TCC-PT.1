
<?php

session_start();	

include("conecta.php");

$id=mysqli_real_escape_string($conexao, $_POST["idregistro"]);
$confirmado=mysqli_real_escape_string($conexao, $_POST["confirmado"]);

if($confirmado==0){
mysqli_query($conexao, "UPDATE registro SET confirmado=1 WHERE id=$id");
}else{
mysqli_query($conexao, "UPDATE registro SET confirmado=0 WHERE id=$id");
}


header("location: ../admin.php");

?>