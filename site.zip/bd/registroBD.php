
<?php

session_start();	



include("conecta.php");

$time=mysqli_real_escape_string($conexao, $_POST["time"]);
$jogador1=mysqli_real_escape_string($conexao, $_POST["jogador1"]);
$jogador2=mysqli_real_escape_string($conexao, $_POST["jogador2"]);
$jogador3=mysqli_real_escape_string($conexao, $_POST["jogador3"]);
$jogador4=mysqli_real_escape_string($conexao, $_POST["jogador4"]);
$jogador5=mysqli_real_escape_string($conexao, $_POST["jogador5"]);
$contato=mysqli_real_escape_string($conexao, $_POST["contato"]);

$duplicidade=mysqli_query($conexao, "select time from registro where time='$time'");
$campotime=mysqli_fetch_array($duplicidade);

$duplicidade2=mysqli_query($conexao, "select contato from registro where contato='$contato'");
$campocontato=mysqli_fetch_array($duplicidade2);

if($time==$campotime["time"]){
	$_SESSION['timeduplicado']="Time já esta cadastrado";
	header("location: ../registrar.php");
	exit;
}

if($contato==$campocontato["contato"]){
	$_SESSION['contatoduplicado']="Contato já esta cadastrado";
	header("location: ../registrar.php");
	exit;
}

mysqli_query($conexao, "INSERT INTO registro (time, jogador1, jogador2, jogador3, jogador4, jogador5, contato, confirmado) VALUES ('$time', '$jogador1', '$jogador2', '$jogador3', '$jogador4', '$jogador5', '$contato', 0)");
$_SESSION['AvisoRegistro']="Time registrado com sucesso! Acesse a aba TORNEIO para maiores informações! Acesse o grupo do whats para confirmar pagamento.";
header("location: ../registrar.php");

?>