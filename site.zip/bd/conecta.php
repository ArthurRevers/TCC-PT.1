
<?php

$conexao=mysqli_connect("localhost", "u587441870_chubakah", "]C2mr:QFnPL", "u587441870_valorant");

?>