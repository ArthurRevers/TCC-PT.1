$(document).ready(function(){
    var totalSlide = $('.slide-item').length;
    var clienteAltura = $('.slide').height();
    var SlideAtual = 0;
    
    $('.slide-width').css("width","calc("+totalSlide+"*100vw)");
    $('.slide-buttons').height(clienteAltura+"px");
    $('.logo').hide().delay(500).fadeIn("slow");

    $('#button1').click(function(){
        volta();
    });

    $('#button2').click(function(){
        passa();
    });

    function passa(){
        SlideAtual++;
        if(SlideAtual > (totalSlide-1)){
            SlideAtual= 0;
        }
        atualizarSlide();
        
    }
    
    function volta(){
        SlideAtual--;
        if(SlideAtual < 0){
            SlideAtual= totalSlide - 1;
        }
        atualizarSlide();
    }
    
    function atualizarSlide(){
        var novaMargem = (SlideAtual * $('.slide-item').width());
        $('.slide-width').css("margin-left","-"+novaMargem+"px");
    }
    setInterval(passa, 5000);
	
		const debounce = function(func, wait, immediate) {
  let timeout;
  return function(...args) {
    const context = this;
    const later = function () {
      timeout = null;
      if (!immediate) func.apply(context, args);
    };
    const callNow = immediate && !timeout;
    clearTimeout(timeout);
    timeout = setTimeout(later, wait);
    if (callNow) func.apply(context, args);
  };
};

const target = document.querySelectorAll('[data-anime]');
const animationClass = 'animate';

function animeScroll() {
  const windowTop = window.pageYOffset + ((window.innerHeight * 3) / 4);
  target.forEach(function(element) {
    if((windowTop) > element.offsetTop) {
      element.classList.add(animationClass);
    } else {
      element.classList.remove(animationClass);
    }
  })
}

animeScroll();

if(target.length) {
  window.addEventListener('scroll', debounce(function() {
    animeScroll();
  }, 200));
}

});